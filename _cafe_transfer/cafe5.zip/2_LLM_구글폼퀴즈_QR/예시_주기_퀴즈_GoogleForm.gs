/**
 * 응용동역학 퀴즈 — 구조물의 주기 : Google Form 자동 생성
 * 사용법: script.google.com → 새 프로젝트 → 이 코드 전체 붙여넣기 → createQuiz 실행 → 권한 허용
 * 실행 로그에 응답용 URL·편집 URL이 나온다.
 *
 * 설정: 퀴즈 모드, 이메일 수집(인증된 이메일), 문항당 5점, 객관식 정답·해설 자동,
 *       단답형 정답은 Forms API로 등록(실패 시 로그 안내대로 수동 입력).
 * 아래 주석은 Forms API 호출용 Drive 권한을 요청하기 위한 것이므로 지우지 말 것:
 * DriveApp.getRootFolder()
 */
const QUIZ = {
 "title": "응용동역학 퀴즈 — 구조물의 주기 (약산식·모드·C_u·푸시오버 입문)",
 "desc": "범위: 10/17 강의 영상 part 1·2 + '04 구조물의 주기' 슬라이드 37~48 (성능점 산정 제외). 5지선다 15문항 + 단답형 5문항, 문항당 5점(총 100점). 단답형 숫자는 단위 없이 지시된 자릿수로 입력.",
 "mc": [
  {
   "lv": "하",
   "q": "해석을 '정적/동적 × 선형/비선형' 네 칸으로 나눌 때, 푸시오버(pushover) 해석은 어디에 속하는가?",
   "opts": [
    "정적 선형",
    "정적 비선형",
    "동적 선형",
    "동적 비선형",
    "어디에도 속하지 않는 별도 방법"
   ],
   "ans": 1,
   "ex": "푸시오버는 별명이고 정확한 이름은 정적 비선형 해석이다. 등가정적해석은 정적 선형, 비선형 시간이력해석은 동적 비선형이다."
  },
  {
   "lv": "하",
   "q": "구조물의 고유주기를 구하는 방법(약산식·고유치해석·계측) 중 신축 건물의 설계 단계에서 쓸 수 없는 것은?",
   "opts": [
    "KDS 약산식 T_a = C_t·h_n^x",
    "MIDAS 고유치해석",
    "센서를 붙인 실측(상시미진동 계측 등)",
    "약산식과 고유치해석 결과의 비교",
    "C_u·T_a 상한을 적용한 해석 주기"
   ],
   "ans": 2,
   "ex": "설계 단계에서는 건물이 없으므로 계측이 불가능하다. 계측은 기존 건축물 평가나 구조 건전성 모니터링(SHM)에서 쓴다."
  },
  {
   "lv": "하",
   "q": "약산식 T_a가 지진 때 계측한 실제 주기 분포의 '짧은 쪽'에 맞춰져 있는 가장 중요한 이유는?",
   "opts": [
    "계산을 단순하게 하기 위해서",
    "장주기 건물의 변위를 크게 평가하기 위해서",
    "상시진동 계측값과 일치시키기 위해서",
    "주기를 짧게 잡아 스펙트럼 하강부에서 지진력을 과소평가하지 않기 위해서",
    "모드해석 결과와 같은 값을 얻기 위해서"
   ],
   "ans": 3,
   "ex": "주기가 길면 스펙트럼 하강부에서 S_a가 작아진다. 짧은 T_a를 기준으로 삼아 지진력을 과소평가하지 않게 한다."
  },
  {
   "lv": "중",
   "q": "학교 건물의 조적 허리벽(창 아래 벽)에 대한 설명으로 옳은 것은?",
   "opts": [
    "허리벽은 비구조재이므로 기둥 거동에 영향을 주지 않는다.",
    "허리벽 높이만큼 기둥이 짧아져 전단(취성)파괴 위험이 커진다.",
    "허리벽은 기둥을 길게 만들어 휨파괴를 유도한다.",
    "해석모델에서 허리벽을 빼면 건물이 더 강하게 평가되어 보수적이다.",
    "이 문제는 주로 최상층 기둥에서 나타난다."
   ],
   "ans": 1,
   "ex": "허리벽이 기둥의 유효 길이를 줄여 단주 효과가 생기고 전단파괴 위험이 커진다(포항 지진 때 학교 기둥 X자 균열). 모델에서 빼면 건물이 유연하게 평가되어 지진력이 과소평가된다. 피해는 주로 1층 기둥에서 나타난다."
  },
  {
   "lv": "중",
   "q": "기존 학교의 허리벽 단주 문제를 해결하는 가장 간단한 방법으로 강의에서 소개한 것은?",
   "opts": [
    "허리벽을 더 높게 쌓는다.",
    "허리벽을 철근콘크리트로 바꿔 기둥과 일체화한다.",
    "기둥의 띠철근 간격을 넓힌다.",
    "허리벽과 기둥 사이를 잘라 슬릿(틈)을 만든다.",
    "해석모델에서 허리벽을 무시한다."
   ],
   "ans": 3,
   "ex": "벽과 기둥 사이를 커팅해 슬릿을 만들면 기둥이 원래 설계 길이대로 거동한다. 이것만으로 부족하면 브레이스·철판·댐퍼로 보강한다."
  },
  {
   "lv": "중",
   "q": "15층 RC 전단벽 아파트(h_n = 45 m)의 근사고유주기에 대한 설명으로 옳은 것은? (C_t = 0.0488, x = 0.75)",
   "opts": [
    "T_a ≈ 0.85초. T_a = 0.1N(=1.5초)은 모멘트골조용이라 쓰면 안 된다.",
    "T_a = 0.1N = 1.5초가 층수 기준이라 우선 적용된다.",
    "T_a ≈ 0.85초와 0.1N = 1.5초 중 긴 값을 택한다.",
    "RC 모멘트골조 식을 써서 T_a ≈ 1.4초로 본다.",
    "두 값의 평균 약 1.2초를 쓴다."
   ],
   "ans": 0,
   "ex": "0.0488 × 45^0.75 ≈ 0.85초. T_a = 0.1N은 12층 이하·층고 3 m 이상의 RC/철골 모멘트골조 전용이다."
  },
  {
   "lv": "중",
   "q": "MIDAS 모드해석 결과 Mode 1(T = 1.12초)의 MPM이 DX 2.0%, DY 26.0%, RZ 49.5%였다. 옳은 해석은?",
   "opts": [
    "Y–비틀림 연성이며 비틀림 지배다. Y방향 설계 주기는 DY가 가장 큰 모드에서 가져온다.",
    "Y 병진 1차 모드이므로 Y방향 설계 주기로 1.12초를 쓴다.",
    "X 병진 1차 모드다.",
    "평면 contour가 한 가지 색으로 고르게 나올 것이다.",
    "응답스펙트럼해석을 하려면 먼저 모든 모드를 병진/비틀림으로 분류해야 한다."
   ],
   "ans": 0,
   "ex": "RZ 49.5% > DY 26.0% → 비틀림 지배. 비틀림 모드는 평면 contour에서 동심원 꼴이 나온다(병진은 한 톤). RSA는 CQC가 연성 모드를 그대로 조합하므로 분류가 필요 없다."
  },
  {
   "lv": "상",
   "q": "MIDAS 모드표에서 비틀림 1차 모드를 찾는 작업에 대한 설명으로 옳지 않은 것은?",
   "opts": [
    "모드 판정은 방향계수(또는 MPM)가 가장 큰 성분으로 한다.",
    "Mode 1부터 내려가며 RZ가 처음 1등이 되는 모드를 비틀림 1차로 본다.",
    "스크립트가 찾은 비틀림 모드는 MIDAS 평면 contour에서 동심원 꼴인지 눈으로 확인한다.",
    "숫자 판정은 LLM에 맡기고, 엔지니어는 결과 설명만 확인하면 된다.",
    "AI 시대에 엔지니어가 맡을 몫은 이해·선택·책임이다."
   ],
   "ans": 3,
   "ex": "판정은 스크립트(규칙), 확인은 엔지니어(contour·형상), 설명은 LLM. 숫자 판정을 LLM에 맡기지 않는다."
  },
  {
   "lv": "중",
   "q": "20층 전후(약 70 m) 건물이 고차모드 측면에서 '애매하다'고 한 이유로 가장 적절한 것은?",
   "opts": [
    "40층 건물은 고차모드가 모두 평탄부에 있어 20층보다 위험하다.",
    "5층 건물은 1차 모드 비중이 작아 고차모드가 지배한다.",
    "2·3차 모드가 스펙트럼의 높은 자리(평탄부 끝 T_S 부근)에 놓여 기여가 커지는데, 1차 위주인 등가정적해석은 이를 직접 보지 못한다.",
    "고차모드 기여는 층수에 비례해 끝없이 커지기 때문이다.",
    "KDS 70 m 기준은 T₂ = T_S가 되는 물리적 전환점에서 유도된 값이기 때문이다."
   ],
   "ans": 2,
   "ex": "높아질수록 고차모드 기여가 커지다가 약 1/3에서 포화된다. 20층 전후에서 2·3차가 스펙트럼의 높은 자리에 놓여 RSA로 확인할 필요가 커진다. 40층은 고차모드도 대부분 하강부(1/T 구간)에 있다. 70 m는 관행적 기하 기준이다."
  },
  {
   "lv": "상",
   "q": "균일 전단빌딩에서 T₁ : T₂ = 1 : 1/3, 유효질량비 M₂*/M₁* = 1/9이다. 두 모드가 모두 스펙트럼 1/T 구간에 있을 때, 2차 모드 밑면전단력 기여 V₂/V₁은?",
   "opts": [
    "1/9",
    "1/5",
    "1/3",
    "1/2",
    "3"
   ],
   "ans": 2,
   "ex": "1/T 구간에서 S_a 비 = T₁/T₂ = 3. V₂/V₁ = 3 × 1/9 = 1/3. 높이를 더 올려도 이 비율로 고정된다(33%에서 포화)."
  },
  {
   "lv": "하",
   "q": "20층 RC 모멘트골조: T_a = 2.13초, C_u·T_a = 3.37초, MIDAS 해석 주기 = 3.90초. 등가정적해석 지진력 산정에 쓰는 주기는?",
   "opts": [
    "2.13초",
    "3.02초(두 값의 평균)",
    "3.37초",
    "3.90초",
    "6.16초(3.90 × 1.58)"
   ],
   "ans": 2,
   "ex": "해석 주기 > C_u·T_a 이면 C_u·T_a를 쓴다. 모델을 너무 무르게 만들어 지진력을 과소평가하지 못하게 막는 안전장치(상한)다."
  },
  {
   "lv": "상",
   "q": "응답스펙트럼해석(RSA)과 약산 주기의 관계로 옳은 것은?",
   "opts": [
    "RSA에서도 각 모드 주기를 C_u·T_a로 잘라서 쓴다.",
    "RSA는 약산법과 완전히 무관하다.",
    "해석 주기가 T_a보다 짧으면 T_a까지 늘려서 쓴다.",
    "스케일업 기준이 되는 등가정적 V는 항상 해석 주기로만 계산한다.",
    "RSA는 모드별 해석 주기를 그대로 쓰되, 밑면전단력이 등가정적 V × 하한비율보다 작으면 스케일업한다. 결국 약산법이 바닥을 정한다."
   ],
   "ans": 4,
   "ex": "RSA는 모델 주기를 상한 없이 쓴다. 대신 등가정적 V(= min(T_해석, C_u·T_a)로 계산)의 하한비율까지 끌어올리므로 C_u·T_a 기준 지진력으로 수렴한다."
  },
  {
   "lv": "중",
   "q": "푸시오버 해석에 대한 설명으로 옳은 것은?",
   "opts": [
    "응답수정계수 R로 줄인 힘으로 탄성 범위 안에서만 민다.",
    "배근 전, 단면 가정만으로 수행하는 초기 설계용 해석이다.",
    "지진 가속도 기록을 시간에 따라 입력하는 동적 해석이다.",
    "응답스펙트럼해석과 같은 선형 해석이다.",
    "탄성 설계로 배근을 끝내 강도가 정해진 뒤, R 없이 하중을 키워가며 미는 해석이다. 하중 단계별 스냅샷을 이은 곡선이다."
   ],
   "ans": 4,
   "ex": "푸시오버는 배근이 끝나 강도가 정해진 상태에서 R 없이 민다. 시간이력이 아니라 하중을 키울 때마다 찍은 스냅샷을 이은 것이다. 그래서 탄성 설계가 먼저다."
  },
  {
   "lv": "상",
   "q": "탄성 설계와 비선형(성능기반) 설계를 비교한 설명으로 옳지 않은 것은?",
   "opts": [
    "탄성 설계에서는 부재력·밑면전단력 등 힘으로 검토했다.",
    "비선형 영역에서도 R로 힘을 줄이면 변위도 같은 비율로 줄어드므로, R만으로 변형을 검토할 수 있다.",
    "항복 이후에는 힘이 아니라 변위(변형)로 컨트롤해야 한다.",
    "역량(capacity)의 핵심은 버티는 힘보다 끊어지기 전까지의 변형 능력이다.",
    "성능수준 IO·LS·CP는 주로 소성힌지 회전각(rad) 같은 변형 지표로 구분한다."
   ],
   "ans": 1,
   "ex": "R은 힘을 바꾸는 계수다. 후크의 법칙대로 힘을 줄이면 변위도 같이 줄어 보이므로, 항복 후의 실제 변형은 R로 알 수 없다. 그래서 비선형 해석으로 변형을 직접 본다."
  },
  {
   "lv": "상",
   "q": "가속도–변위 응답스펙트럼(ADRS) 표기에 대한 설명으로 옳지 않은 것은?",
   "opts": [
    "가로축은 스펙트럴 변위 S_d, 세로축은 스펙트럴 가속도 S_a다.",
    "S_a = ω²·S_d 관계로 변위·가속도 스펙트럼을 한 평면에 합친다.",
    "주기는 원점을 지나는 방사 직선으로 나타난다.",
    "직선의 기울기가 ω²(강성)에 대응하므로, 항복하며 주기가 길어지는 과정이 '직선이 눕는 것'으로 보인다.",
    "주기가 길수록(더 유연할수록) 그 직선은 더 가팔라진다."
   ],
   "ans": 4,
   "ex": "주기가 길수록 ω²가 작아져 직선이 눕는다(기울기 감소 = 강성 감소). 주기↑ = 강성↓ = 기울기↓."
  }
 ],
 "sa": [
  {
   "lv": "하",
   "q": "12층 이하·층고 3 m 이상인 5층 RC 모멘트골조의 근사고유주기를 T_a = 0.1N으로 구하시오. (초, 숫자만)",
   "ans": [
    "0.5",
    "0.50",
    "0.5초"
   ],
   "ex": "T_a = 0.1 × 5 = 0.5초. RC·철골 모멘트골조에만 쓰는 간편식이다."
  },
  {
   "lv": "중",
   "q": "높이 70 m(20층) RC 모멘트골조의 근사고유주기 T_a(초)를 구하시오. (C_t = 0.0466, x = 0.9, 소수 둘째 자리까지, 숫자만)",
   "ans": [
    "2.13",
    "2.13초",
    "2.13s"
   ],
   "ex": "T_a = 0.0466 × 70^0.9 = 0.0466 × 45.8 ≈ 2.13초."
  },
  {
   "lv": "상",
   "q": "S_D1 = 0.16인 부지의 주기상한계수 C_u를 구하시오. (표 7.2-1: S_D1 0.15 → 1.6, 0.2 → 1.5, 중간값은 직선보간, 소수 둘째 자리까지)",
   "ans": [
    "1.58"
   ],
   "ex": "1.6 − (1.6 − 1.5) × (0.16 − 0.15)/(0.20 − 0.15) = 1.58. (예: T_a 2.13초 → 상한 3.37초)"
  },
  {
   "lv": "중",
   "q": "허리벽 때문에 기둥의 유효 길이가 짧아져 전단파괴 위험이 커지는 현상을 무엇이라 하는가? (한국어 용어)",
   "ans": [
    "단주효과",
    "단주 효과",
    "단주",
    "short column effect",
    "Short column effect"
   ],
   "ex": "단주(짧은 기둥) 효과. 짧아진 기둥은 강성이 커져 힘이 몰리고 취성적인 전단파괴가 먼저 온다."
  },
  {
   "lv": "하",
   "q": "소성힌지 회전각으로 구분하는 성능수준 IO·LS·CP 중 '인명안전'의 영문 약어는?",
   "ans": [
    "LS",
    "ls",
    "Life Safety",
    "life safety",
    "Life safety"
   ],
   "ex": "IO = 즉시거주, LS = 인명안전, CP = 붕괴방지."
  }
 ]
};
const POINTS = 5;

function createQuiz() {
  const form = FormApp.create(QUIZ.title);
  form.setDescription(QUIZ.desc);
  form.setIsQuiz(true);
  try {
    form.setEmailCollectionType(FormApp.EmailCollectionType.VERIFIED);
  } catch (e) {
    form.setCollectEmail(true);
  }
  form.setShowLinkToRespondAgain(false);
  form.setProgressBar(true);

  let n = 0;
  QUIZ.mc.forEach(function (m) {
    n++;
    const item = form.addMultipleChoiceItem();
    item.setTitle(n + '. [' + m.lv + '] ' + m.q).setPoints(POINTS).setRequired(true);
    item.setChoices(m.opts.map(function (o, i) { return item.createChoice(o, i === m.ans); }));
    item.setFeedbackForCorrect(FormApp.createFeedback().setText('정답. ' + m.ex).build());
    item.setFeedbackForIncorrect(FormApp.createFeedback().setText(m.ex).build());
  });

  const firstSa = n;
  QUIZ.sa.forEach(function (s) {
    n++;
    const item = form.addTextItem();
    item.setTitle(n + '. [' + s.lv + '·단답] ' + s.q).setPoints(POINTS).setRequired(true);
    item.setGeneralFeedback(FormApp.createFeedback().setText('정답 ' + s.ans[0] + '. ' + s.ex).build());
  });

  try {
    setShortAnswerKeys_(form.getId(), firstSa);
    Logger.log('단답형 정답 자동 등록 완료');
  } catch (e) {
    Logger.log('단답형 정답 자동 등록 실패: ' + e);
    Logger.log('→ 폼 편집 화면에서 16~20번 "답안" 버튼으로 아래 정답을 직접 입력:');
    QUIZ.sa.forEach(function (s, i) { Logger.log((firstSa + i + 1) + '번: ' + s.ans.join(' / ')); });
  }

  Logger.log('응답용 URL: ' + form.getPublishedUrl());
  Logger.log('편집 URL:   ' + form.getEditUrl());
}

function setShortAnswerKeys_(formId, firstIndex) {
  const url = 'https://forms.googleapis.com/v1/forms/' + formId;
  const headers = { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() };
  const res = UrlFetchApp.fetch(url, { headers: headers, muteHttpExceptions: true });
  if (res.getResponseCode() !== 200) throw new Error('GET ' + res.getResponseCode() + ' ' + res.getContentText());
  const items = JSON.parse(res.getContentText()).items;
  const requests = QUIZ.sa.map(function (s, i) {
    const idx = firstIndex + i;
    const it = items[idx];
    it.questionItem.question.grading = {
      pointValue: POINTS,
      correctAnswers: { answers: s.ans.map(function (a) { return { value: a }; }) },
      generalFeedback: { text: '정답 ' + s.ans[0] + '. ' + s.ex }
    };
    return { updateItem: { item: it, location: { index: idx }, updateMask: 'questionItem.question.grading' } };
  });
  const r = UrlFetchApp.fetch(url + ':batchUpdate', {
    method: 'post', contentType: 'application/json', headers: headers,
    payload: JSON.stringify({ requests: requests }), muteHttpExceptions: true
  });
  if (r.getResponseCode() !== 200) throw new Error('batchUpdate ' + r.getResponseCode() + ' ' + r.getContentText());
}
